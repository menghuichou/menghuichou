#include <iostream>
#include <string>
#include <cstdlib>
#include "cyberdemon.h"
#include "demon.h"
using namespace std;

namespace cs_creature {

    Cyberdemon::Cyberdemon() :Demon()
    {
    }






    Cyberdemon::Cyberdemon(int newStrength, int newHitpoints) :
        Demon(newStrength, newHitpoints)
    {
    }






    string Cyberdemon::getSpecies() const
    {
        string spacies = "Cyberdemon";
        return spacies;
    }





    /*
    int Cyberdemon::getDamage() const
    {
        int total;

        //cout << "The " << getSpecies();

        total = Demon::getDamage();
        return total;
    }
    */
}