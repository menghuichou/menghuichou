#ifndef ELF_H
#define ELF_H

#include <iostream>
#include <string>
#include "BaseCreature.h"
using namespace std;

namespace cs_creature {

    class Elf : public Creature {
    public:
        Elf();
        Elf(int newStrength, int newHitpoints);
        string getSpecies() const;
        int getDamage() const;
    };

}
#endif