#include <iostream>
#include <string>
#include <cstdlib>
#include "BaseCreature.h"

using namespace std;
namespace cs_creature {

    Creature::Creature()
    {
        strength = 10;
        hitpoints = 10;
    }






    Creature::Creature(int newStrength, int newHitpoints)
    {
        strength = newStrength;
        hitpoints = newHitpoints;
    }






    void Creature::setStrength(int theStrength)
    {
        strength = theStrength;
    }






    void Creature::setHitpoints(int theHitpoints)
    {
        hitpoints = theHitpoints;
    }






    int Creature::getStrength() const
    {
        return strength;
    }






    int Creature::getHitpoints() const
    {
        return hitpoints;
    }






    int Creature::getDamage() const
    {
        int damage;

        // All Creatures inflict damage which is a random number up to their strength
        damage = (rand() % strength) + 1;

        cout << "The " << getSpecies() << " attacks for " << damage << " points!" << endl;

        return damage;
    }




    /*
    string Creature::getSpecies() const
    {
        string species = "Creature";
        return species;
    }
    */
}