#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "balrog.h"
#include "BaseCreature.h"
#include "cyberdemon.h"
#include "demon.h"
#include "human.h"
#include "elf.h"
using namespace cs_creature;
using namespace std;

void battleArena(Creature &Creature1, Creature& Creature2);

int main() {
    srand(static_cast<unsigned>(time(nullptr)));

    Elf e(50, 50);
    Balrog b(50, 50);
    Human h(50, 50);
    Cyberdemon c(50, 50);

    cout << "-----Elf v.s Balrog-----" << endl;
    battleArena(e, b);
    cout << endl << "-----Human v.s Balrog-----" << endl;
    battleArena(h, b);
    cout << endl << "-----Cyberdemon v.s Human-----" << endl;
    battleArena(c, h);
    cout << endl << "-----Elf v.s Human-----" << endl;
    battleArena(e, h);
    cout << endl << "-----Elf v.s Cyberdemon-----" << endl;
    battleArena(e, c);
    cout << endl << "-----Balrog v.s Cyberdemon-----" << endl;
    battleArena(b, c);
}






void battleArena(Creature &Creature1, Creature& Creature2)
{
    int live1, live2;
    live1 = Creature1.getDamage() - Creature2.getHitpoints();
    live2 = Creature2.getDamage() - Creature1.getHitpoints();
    if (live1 > 0 && live2 > 0)
    {
        do
        {
            live1 = Creature1.getDamage() - Creature2.getHitpoints();
            live2 = Creature2.getDamage() - Creature1.getHitpoints();

        } while (live1 > 0 && live2 > 0);
    }
}






/*----Paste of Run----
-----Elf v.s Balrog-----
The Elf attacks for 32 points!
Magical attack inflicts 32 additional damage points!
The Balrog attacks for 10 points!
Balrog speed attack inflicts 48 additional damage points!
The Elf attacks for 14 points!
Magical attack inflicts 14 additional damage points!
The Balrog attacks for 4 points!
Balrog speed attack inflicts 32 additional damage points!

-----Human v.s Balrog-----
The Human attacks for 12 points!
The Balrog attacks for 48 points!
Balrog speed attack inflicts 25 additional damage points!

-----Cyberdemon v.s Human-----
The Cyberdemon attacks for 28 points!
Demonic attack inflicts 50 additional damage points!
The Human attacks for 20 points!

-----Elf v.s Human-----
The Elf attacks for 48 points!
Magical attack inflicts 48 additional damage points!
The Human attacks for 10 points!

-----Elf v.s Cyberdemon-----
The Elf attacks for 12 points!
Magical attack inflicts 12 additional damage points!
The Cyberdemon attacks for 41 points!

-----Balrog v.s Cyberdemon-----
The Balrog attacks for 24 points!
Demonic attack inflicts 50 additional damage points!
Balrog speed attack inflicts 16 additional damage points!
The Cyberdemon attacks for 20 points!

C:\Users\varna\OneDrive\���\Visual Studio 2017\a7\Debug\a7.exe (process 196) exited with code 0.
Press any key to close this window . . .


*/
