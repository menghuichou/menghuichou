#ifndef DEMON_H
#define DEMON_H

#include <iostream>
#include <string>
#include "BaseCreature.h"
using namespace std;

namespace cs_creature {

    class Demon : public Creature {
    public:
        Demon();
        Demon(int newStrength, int newHitpoints);
        string getSpecies() const;
        int getDamage() const;
    };

}
#endif
