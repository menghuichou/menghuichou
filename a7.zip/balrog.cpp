#include <iostream>
#include <string>
#include <cstdlib>
#include "balrog.h"
#include "demon.h"
using namespace std;

namespace cs_creature {

    Balrog::Balrog() :Demon()
    {
    }






    Balrog::Balrog(int newStrength, int newHitpoints) :
        Demon(newStrength, newHitpoints)
    {
    }






    string Balrog::getSpecies() const
    {
        string spacies = "Balrog";
        return spacies;
    }






    int Balrog::getDamage() const
    {
        int damage, damage2, total;

        //cout << "The " << getSpecies();
        damage = Demon::getDamage();

        damage2 = (rand() % getStrength()) + 1;

        cout << "Balrog speed attack inflicts " << damage2 << " additional damage points!" << endl;
        total = damage + damage2;
        return total;
    }

}