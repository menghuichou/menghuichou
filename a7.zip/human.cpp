#include <iostream>
#include <string>
#include <cstdlib>
#include "BaseCreature.h"
#include "human.h"
using namespace std;

namespace cs_creature {

    Human::Human() :Creature()
    {
    }






    Human::Human(int newStrength, int newHitpoints) :
        Creature(newStrength, newHitpoints)
    {
    }






    string Human::getSpecies() const
    {
        string spacies = "Human";
        return spacies;
    }

   



/*
    int Human::getDamage() const
    {
        int damage;

        damage = Creature::getDamage();
        //cout << "The " << getSpecies() << " attacks for " << damage << " points!" << endl;

        return damage;
    }
*/
}