#include <iostream>
#include "sequence.h"
#include <cassert>
using namespace std;

namespace cs_sequence {

    Sequence::Sequence()
    {
        numItems = 0;
        headPtr = nullptr;
        tailPtr = nullptr;
        cursor = nullptr;
        precursor = nullptr;
    }







    void Sequence::start()
    {
        if (headPtr != nullptr)
        {
            cursor = headPtr;
        }
        else
        {
            cursor = nullptr;
            precursor = nullptr;
            tailPtr = nullptr;
        }
    }






    void Sequence::advance()
    {
        if (cursor->next != nullptr)
        {
            precursor = cursor;
            cursor = cursor->next;
        }

        else
        {
            tailPtr = cursor;
            cursor = nullptr;
            precursor = nullptr;
        }

    }






    void Sequence::insert(const value_type& entry) {

        node* new_node = new node;
        new_node->data = entry;
        numItems++;
        
        
        if (cursor == headPtr || cursor == nullptr) { // insert at front (or into empty list).
            new_node->next = headPtr;                 // precursor remains nullptr.
            headPtr = new_node;
            if (numItems == 1) {
                tailPtr = new_node;
            }
        }
        

        else {                                       // inserting anywhere else
            new_node->next = cursor;                   // tailPtr, headPtr and precursor don't change.
            precursor->next = new_node;
        }

        cursor = new_node;
    }






    Sequence::size_type Sequence::size() const
    {
        node* tempPtr = headPtr;
        size_type count = 0;
        while (tempPtr != nullptr) {
            count++;
            tempPtr = tempPtr->next;
        }

        return count;
    }






    bool Sequence::is_item() const
    {
        if (headPtr != nullptr && cursor != nullptr)
        {
            return true;
        }
        else
            return false;
    }






    Sequence::value_type Sequence::current() const
    {
        return cursor->data;
    }






    void Sequence::attach(const value_type& entry)
    {
        node* new_node = new node;
        new_node->data = entry;
        numItems++;

        if (cursor == nullptr) 
        {
            if (headPtr == nullptr)
            {
                headPtr = new_node;
                new_node->next = nullptr;
                tailPtr = new_node;
            }
            else
            {
                tailPtr->next = new_node;
                new_node->next = nullptr;
                precursor = tailPtr;
                tailPtr = new_node;
            }
        }
        else {
                new_node->next = cursor->next;
                cursor->next = new_node;
                precursor = cursor;
        }

        cursor = new_node;
    }






    void Sequence::remove_current()
    {
        assert(is_item() == true);
        node* tempptr = new node;

        if (cursor == headPtr && cursor->next == nullptr)
        {
            tempptr->next = headPtr;
            headPtr = nullptr;
            cursor = nullptr;
            tailPtr = nullptr;
            delete tempptr;
        }
        else if (cursor == headPtr && cursor->next != nullptr)
        {
            tempptr->next = headPtr;
            cursor = cursor->next;
            headPtr = headPtr->next;
            delete tempptr;
        }
        else
        {
            if (cursor->next != nullptr)
            {
                tempptr->next = cursor;
                cursor = cursor->next;
                precursor->next = cursor;
                delete tempptr;
            }
            else
            {
                tempptr->next = cursor;
                cursor = nullptr;
                precursor->next = nullptr;
                delete tempptr;
                tailPtr = precursor;
                precursor = nullptr;
            }
        }
    }






    Sequence Sequence:: operator=(const Sequence& right)
    {
        if (this != &right)
        {
            clear();
            copy(right);
        }
        return *this;
    }






    Sequence::Sequence(const Sequence& copyMe)
    {
        copy(copyMe);
    }







    void Sequence::copy(const Sequence& copyMe)
    {
        if (copyMe.headPtr == nullptr)
        { 
            headPtr = nullptr;
            cursor = nullptr;
            precursor = nullptr;
            tailPtr = nullptr;
        }
        else
        {
            headPtr = new node;
            headPtr->data = copyMe.headPtr->data;

            node* newptr = headPtr;
            node* sourceptr = copyMe.headPtr->next;

            while (sourceptr != nullptr)
            {
                newptr->next = new node;
                newptr = newptr->next;
                newptr->data = sourceptr->data;
                sourceptr = sourceptr->next;
            }

            start();
            tailPtr = newptr;
            newptr->next = nullptr;

            if (copyMe.is_item() == true)
            {
                while (cursor->data != copyMe.current())
                {
                    advance();
                }
            }
            else
            {
                cursor = nullptr;
                precursor = nullptr;
            }
        }
    }






    Sequence::~Sequence()
    {
        clear();
    }






    void Sequence::clear()
    {
        node* tempptr = headPtr;
        while (tempptr != nullptr)
        {
            headPtr = headPtr->next;
            delete tempptr;
            tempptr = headPtr;
        }
    }
}




